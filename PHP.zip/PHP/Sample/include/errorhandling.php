<?php

echo "please adjust the preferences stored in the settings folder</br>- check the ROOT setting and adjust if necessary</br><a href='../'>retry</a>" ;

?>